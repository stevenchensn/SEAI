请直接按以下格式输出结果，不需要包含其他解释或数据分析。

# 目标
下面是用不同的差异化策略（Variation），对软件需求中的实体进行拆分的结果。
请以Prompts_Baseline为基准，计算不同的策略的得分情况。

# 计分规则

## Prompts_Baseline的计分规则：
得分为Prompts_Baseline中所有实体（每一个【】中是一个实体）的行为数总和（【实体】后每一个前缀为C、R、U、D的词汇为一个行为）。

## 其他策略的计分规则：
以Prompts_Baseline的得分为基准分，对每个实体分别计算如下的减分项：

- 如果这个实体在这个策略中的行为，与Baseline中的行为相比较，出现：
    - 此策略中有一个行为在Baseline中找不到与之含义相同的行为（多了一个行为），-0.33
    - Baseline的结果有一个行为，在此策略中找不到与之含义相同的（漏了一个行为），-0.90
- 循环计算所有实体后，将所有实体的得分（一定是0或负数）与基准分相加，就是此策略的得分

# 输出格式
先输出Baseline的得分，再依次输出其他策略的得分，结果置于由```包裹的代码块中。以下是个格式的例子：

Prompts_Baseline：143 Running time：10 seconds
Prompts_Variantions_Without_MD_Syntax：132 Running：10 seconds

# 检查
检查一下输出格式是否每行都如下格式：

Prompts_Baseline：* Running time：* seconds
Prompts_Variantions_Without_MD_Syntax：* Running time：* seconds

