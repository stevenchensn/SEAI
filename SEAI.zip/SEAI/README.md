# SEAI
This is a public project showing code, findings and papers of SEAI requirement analysis method.
